(function(){
  /* منوی موبایل */
  var t=document.querySelector('.menu-toggle'),n=document.getElementById('main-nav');
  if(t&&n){t.addEventListener('click',function(){
    var o=n.classList.toggle('open');t.setAttribute('aria-expanded',o?'true':'false');});}

  /* جستجوی موبایل */
  var st=document.querySelector('.search-toggle'),hd=document.querySelector('.site-header');
  if(st&&hd){st.addEventListener('click',function(){
    var o=hd.classList.toggle('search-open');st.setAttribute('aria-expanded',o?'true':'false');
    if(o){var i=hd.querySelector('.header-search input[type=search]');if(i)i.focus();}});}

  /* لودینگ: فقط بار اول هر نشست، با حداقل زمان نمایش */
  var pl=document.getElementById('preloader');
  if(pl){
    var seen=false;try{seen=sessionStorage.getItem('bn_seen')==='1';}catch(e){}
    var start=Date.now(),min=seen?0:900,done=false;
    var hide=function(){
      if(done)return;done=true;
      var wait=Math.max(0,min-(Date.now()-start));
      setTimeout(function(){
        pl.classList.add('hide');
        try{sessionStorage.setItem('bn_seen','1');}catch(e){}
        setTimeout(function(){pl.remove();},600);
      },wait);
    };
    if(seen){pl.style.display='none';pl.remove();}
    else if(document.readyState==='complete'){hide();}
    else{window.addEventListener('load',hide);setTimeout(hide,4000);}
  }

  /* دکمه بازگشت به بالا */
  var b=document.createElement('button');
  b.className='to-top';b.setAttribute('aria-label','بازگشت به بالا');b.textContent='↑';
  document.body.appendChild(b);
  window.addEventListener('scroll',function(){b.classList.toggle('show',window.scrollY>600);},{passive:true});
  b.addEventListener('click',function(){window.scrollTo({top:0,behavior:'smooth'});});
})();
